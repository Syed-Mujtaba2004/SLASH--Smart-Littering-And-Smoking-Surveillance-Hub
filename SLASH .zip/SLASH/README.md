# Smart Surveillance System v5

A real-time AI-powered surveillance system that detects public violations — smoking, littering, and loitering — and identifies offenders using facial recognition. Deployed on an NVIDIA Jetson Orin Nano as a Final Year Project.

![Python](https://img.shields.io/badge/Python-3.10-blue)
![YOLOv8](https://img.shields.io/badge/YOLOv8-Ultralytics-purple)
![InsightFace](https://img.shields.io/badge/InsightFace-ArcFace-green)
![MongoDB](https://img.shields.io/badge/MongoDB-Atlas-brightgreen)
![Jetson](https://img.shields.io/badge/Edge-Jetson%20Orin%20Nano-orange)

---

## What It Does

| Violation | How It Is Detected |
|---|---|
| Smoking | YOLOv8 cigarette detection + pose keypoints + smoke plume analysis |
| Littering | Object trajectory tracking + velocity thresholding + arm-throw pose |
| Loitering | Grid-snapped person dwell timer exceeding 30 seconds |

When a violation is confirmed the system:
- Saves an annotated JPEG snapshot and JSON alert metadata
- Logs the event to MongoDB Atlas (with offline-first local fallback)
- Pushes a live alert to a Node-RED dashboard
- Optionally fires a webhook to an external endpoint

---

## System Architecture

```
Camera / Video / RTSP
        │
        ▼
┌─────────────────────────────────────┐
│         Frame Processing Loop        │
│                                      │
│  ┌──────────┐  ┌──────────────────┐  │
│  │ YOLOv8   │  │  YOLOv8n-Pose   │  │
│  │ best1.pt │  │  17 keypoints   │  │
│  │ best2.pt │  └──────────────────┘  │
│  └──────────┘                        │
│  ┌──────────────────────────────┐    │
│  │  Violation Detectors         │    │
│  │  SmokingDetector             │    │
│  │  LitteringDetector           │    │
│  │  LoiteringDetector           │    │
│  └──────────────────────────────┘    │
│  ┌──────────────────────────────┐    │
│  │  FaceRecognizer (ArcFace)    │    │
│  │  512-d cosine similarity     │    │
│  └──────────────────────────────┘    │
└─────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────┐
│           AlertManager               │
│  JPEG · JSON · MongoDB · Node-RED   │
└─────────────────────────────────────┘
```

---

## Models Used

| Model | Purpose |
|---|---|
| `best1.pt` / `best2.pt` | Custom YOLOv8 trained on cigarette + trash dataset |
| `yolov8n-pose.pt` | Human pose estimation (17 COCO keypoints) |
| `yolov8n.pt` | COCO fallback for additional trash classes |
| InsightFace `buffalo_l` | RetinaFace detection + ArcFace 512-d face embeddings |

---

## Project Structure

```
smart-surveillance/
├── slashf.py               # Main system — detectors, pipeline, menu
├── db.py                   # MongoDB Atlas + local fallback (SurveillanceDB)
├── models/
│   ├── best1.pt            # Custom YOLO model A (not included — see below)
│   ├── best2.pt            # Custom YOLO model B (not included — see below)
│   └── yolov8n-pose.pt     # Downloaded automatically by Ultralytics
├── known_faces/            # Reference images for face enrollment
├── alerts/                 # Saved JPEG + JSON alert files (auto-created)
├── .env.example            # Environment variable template
├── requirements.txt        # Python dependencies
└── README.md
```

> Custom model weights (`best1.pt`, `best2.pt`) are not included due to file size. Contact us or see the Training section below.

---

## Setup

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/smart-surveillance.git
cd smart-surveillance
```

### 2. Create a virtual environment

```bash
python3 -m venv surveillance_env
source surveillance_env/bin/activate        # Linux / Mac
surveillance_env\Scripts\activate           # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` and fill in your values:

```
ATLAS_URI=mongodb+srv://your_user:your_password@your_cluster.mongodb.net/
CAMERA_ID=jetson_orin_nano
LOCATION=Lab
```

### 5. Add model weights

Place your trained model files in the `models/` folder:

```
models/best1.pt
models/best2.pt
```

`yolov8n-pose.pt` and `yolov8n.pt` will be downloaded automatically on first run.

### 6. Run

```bash
python3 slashf.py
```

---

## Menu Options

```
[1]  Image file
[2]  Video file
[3]  Webcam
[4]  IP / RTSP camera
[5]  Enroll a face
[6]  List enrolled faces
[7]  Set watchlist flag
[X]  Exit
```

---

## Face Enrollment

To enroll a person for identification:

1. Run the system and select option `[5]`
2. Provide the person's name and an image path
3. The embedding is saved to `faces.npy` and `faces_meta.json`
4. To flag someone as a watchlist subject, select option `[7]`

---

## Training Your Own Models

The custom models were trained using transfer learning on YOLOv8:

```bash
yolo train model=yolov8n.pt data=dataset.yaml epochs=100 imgsz=640
```

Dataset structure (YOLO format):

```
dataset/
├── images/
│   ├── train/
│   └── val/
├── labels/
│   ├── train/
│   └── val/
└── dataset.yaml
```

`dataset.yaml` example:

```yaml
nc: 2
names: ['cigarette', 'trash']
train: images/train
val:   images/val
```

---

## Deployment Notes (Jetson Orin Nano)

Running four concurrent models on the Jetson's shared GPU/CPU memory pool causes CUDA OOM. The system handles this automatically by:

- Forcing all YOLO models to CPU (`YOLO_DEVICE = "cpu"`)
- Downscaling frames before inference (`INFER_RESIZE = 480`)
- Processing every 2nd frame (`FRAME_SKIP = 2`)
- Running the COCO fallback every 3rd frame (`COCO_SKIP_FRAMES = 3`)

These defaults are tuned for stable real-time performance on the Jetson Orin Nano.

---

## Configuration

Key parameters in `slashf.py`:

| Parameter | Default | Description |
|---|---|---|
| `YOLO_DEVICE` | `"cpu"` | Inference device (`"cpu"` or `"cuda"`) |
| `INFER_RESIZE` | `480` | Max frame size before inference |
| `FRAME_SKIP` | `2` | Process every Nth frame |
| `FACE_SIM_THRESHOLD` | `0.45` | Cosine similarity threshold for face matching |
| `SMOKING_CONFIRM_FRAMES` | `3` | Frames required to confirm smoking |
| `LOITER_SECONDS` | `30` | Dwell time before loitering alert |
| `ALERT_COOLDOWN_SEC` | `2` | Minimum seconds between alerts per offender |

---

## Node-RED Dashboard

The system pushes live alerts and annotated frames to Node-RED at:

```
http://localhost:1880/surveillance/alert   ← violation alerts
http://localhost:1880/surveillance/frame   ← live annotated feed (2 fps)
```

Install Node-RED: https://nodered.org/docs/getting-started/

---

## Tech Stack

- [Ultralytics YOLOv8](https://github.com/ultralytics/ultralytics)
- [InsightFace](https://github.com/deepinsight/insightface)
- [OpenCV](https://opencv.org)
- [MongoDB Atlas](https://www.mongodb.com/atlas)
- [Node-RED](https://nodered.org)
- [NVIDIA Jetson Orin Nano](https://www.nvidia.com/en-us/autonomous-machines/embedded-systems/jetson-orin/)

---

## Team

Final Year Project — Team of 3

---

## License

This project is for academic and research purposes.
