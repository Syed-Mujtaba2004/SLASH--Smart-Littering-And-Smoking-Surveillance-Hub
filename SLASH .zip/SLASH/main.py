"""
Smart Surveillance System v5 — Core Edition
============================================
Combines:
  - MongoDB integration (SurveillanceDB)
  - Stationary trash locking (StationaryTrashRegistry)
  - Face recognition (InsightFace / ArcFace)
  - Loitering detector
  - Smoking detector (pose + cigarette proximity)
  - Littering detector (trajectory + arm-throw)
  - Alert manager (image save, JSON, MongoDB, webhook)
  - Node-RED real-time dashboard (alerts + live annotated camera feed)

Requirements:
    pip install ultralytics opencv-python numpy insightface onnxruntime
    pip install pymongo python-dotenv certifi

.env file (same folder):
    ATLAS_URI=mongodb+srv://user:pass@cluster.mongodb.net/
    CAMERA_ID=jetson_orin_nano
    LOCATION=Lab
"""

import argparse
import collections
import json
import os
import queue
import threading
import time
from pathlib import Path

import cv2
import numpy as np

try:
    import insightface
    from insightface.app import FaceAnalysis
    INSIGHTFACE_OK = True
except ImportError:
    INSIGHTFACE_OK = False
    print("[WARN] insightface not installed — facial recognition disabled.")

from ultralytics import YOLO

from db import SurveillanceDB


# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

DEFAULT_MODEL_A        = "models/best1.pt"
DEFAULT_MODEL_B        = "models/best2.pt"
POSE_MODEL_PATH        = "models/yolov8n-pose.pt"
COCO_FALLBACK_PATH     = "models/yolov8n.pt"

# ── Device / memory management ────────────────
# Force YOLO models to CPU to avoid CUDA OOM on Jetson shared memory.
# InsightFace already uses CPUExecutionProvider — this keeps all inference
# on the same device and avoids the GPU filling up across 4+ models.
YOLO_DEVICE            = "cpu"

# Downscale frames before YOLO inference to cut memory and inference time.
# 640 = full YOLO input. 480 is a safe Jetson-friendly value.
# Set to None to disable (uses native camera resolution).
INFER_RESIZE           = 480

CONF_THRESHOLD         = 0.40
TRASH_CONF_THRESHOLD   = 0.30
CIG_CONF_THRESHOLD     = 0.60
COMBINED_CONF_GATE     = 0.50
# Process every Nth frame. 1 = every frame. 2 halves load on Jetson.
FRAME_SKIP             = 2
TRAJECTORY_HISTORY     = 20
ALERT_COOLDOWN_SEC     = 2
# Run COCO fallback every Nth frame to further reduce load.
COCO_SKIP_FRAMES       = 3

SAVEABLE_CONFIDENCES   = {"HIGH", "MEDIUM"}

# ── Face recognition ──────────────────────────
FACE_DB_PATH           = "faces.npy"
FACE_META_PATH         = "faces_meta.json"
FACE_SIM_THRESHOLD     = 0.45
FACE_DET_SCORE_MIN     = 0.60
ENROLL_UNKNOWN         = False
FACE_RECOGNITION_EVERY = 3
FACE_ON_OFFENDER_ONLY  = True

# ── Temporal smoother ─────────────────────────
TEMPORAL_CONFIRM_FRAMES = 4
TEMPORAL_DECAY          = 1

# ── Smoking ───────────────────────────────────
HAND_MOUTH_DIST_THRESH  = 0.14
WRIST_CONF_MIN          = 0.40
CIG_FACE_IOU_MIN        = 0.04
CIG_FACE_DIST_MAX       = 100
FACE_REGION_FRAC        = 0.40
FACE_EXPAND_X           = 0.25
SMOKING_CONFIRM_FRAMES  = 3
SMOKING_DECAY           = 0.5
PERSON_MATCH_IOU_MIN    = 0.35
SMOKE_PLUME_ENABLED     = True
SMOKE_PLUME_MIN_PIXELS  = 200

# ── Littering ─────────────────────────────────
THROW_VELOCITY_THRESH   = 22
ARM_EXTEND_THRESH       = 0.35
ARM_RISE_THRESH         = 0.35
TRASH_MIN_TRACK_LEN     = 2
LITTER_PROXIMITY_PX     = 100
ARM_WRIST_MOVE_MIN      = 15
OBJECT_LEAVE_HAND_PX    = 60

# ── Loitering ─────────────────────────────────
LOITER_SECONDS          = 30
LOITER_ZONES            = []

# ── Evidence ──────────────────────────────────
SAVE_VIDEO_CLIP         = False
CLIP_BUFFER_SECONDS     = 3
WEBHOOK_URL             = None

# ── Stationary trash locking ──────────────────
STATIONARY_LOCK_FRAMES  = 12
STATIONARY_MOVE_THRESH  = 8
STATIONARY_PURGE_FRAMES = 60

# ── Extended COCO trash classes ───────────────
COCO_TRASH_CLASSES = {
    39: "bottle", 41: "cup", 25: "handbag", 67: "cell phone",
    73: "book",   74: "clock", 43: "knife", 44: "spoon",
    45: "bowl",   46: "banana", 47: "apple", 49: "orange",
    51: "carrot", 52: "hot dog", 53: "pizza", 54: "donut",
    55: "cake",   76: "scissors", 77: "teddy bear", 79: "toothbrush",
    26: "umbrella", 28: "suitcase", 32: "sports ball",
}

CIGARETTE_NAMES = {"cigarette", "cig", "smoke", "smoking"}
TRASH_NAMES     = {"trash", "litter", "garbage", "waste",
                   "rubbish", "bottle", "plastic", "bag", "wrapper"}

COL_SMOKING    = (0,   0,   255)
COL_TRASH      = (0,   165, 255)
COL_PERSON     = (180, 180, 180)
COL_INFO       = (50,  205,  50)
COL_POSE       = (0,   255, 200)
COL_DEBUG      = (255, 255,   0)
COL_FACE_OK    = (0,   255,   0)
COL_FACE_WL    = (0,   0,   255)
COL_FACE_UNK   = (255, 165,   0)
COL_LOITER     = (128,   0, 128)
COL_STATIONARY = (100, 100, 100)

KP_NOSE           = 0
KP_LEFT_SHOULDER  = 5
KP_RIGHT_SHOULDER = 6
KP_LEFT_WRIST     = 9
KP_RIGHT_WRIST    = 10

_FONT = cv2.FONT_HERSHEY_SIMPLEX

# ── Node-RED integration ──────────────────────
NODE_RED_URL       = "http://localhost:1880/surveillance/alert"
NODE_RED_FRAME_URL = "http://localhost:1880/surveillance/frame"
NR_FRAME_FPS       = 2
_NR_LAST_FRAME_TS  = 0.0


# ─────────────────────────────────────────────
# NODE-RED SENDERS
# ─────────────────────────────────────────────

def notify_node_red(label, confidence, bounding_box, image_path,
                    offender_key, metadata=None):
    """Fire-and-forget POST to Node-RED /surveillance/alert."""
    def _send():
        try:
            import urllib.request
            payload = json.dumps({
                "type":         label,
                "confidence":   confidence,
                "bounding_box": bounding_box,
                "image_path":   str(image_path),
                "offender_key": str(offender_key),
                "timestamp":    time.strftime("%Y-%m-%dT%H:%M:%S"),
                "camera_id":    os.getenv("CAMERA_ID", "jetson_orin_nano"),
                "face_name":    (metadata or {}).get("face_name"),
            }).encode("utf-8")
            req = urllib.request.Request(
                NODE_RED_URL, data=payload,
                headers={"Content-Type": "application/json"}, method="POST")
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass
    threading.Thread(target=_send, daemon=True).start()


def send_frame_to_node_red(frame):
    """
    Send the fully-annotated display frame to Node-RED /surveillance/frame.
    Throttled to NR_FRAME_FPS fps. Runs in a daemon thread so it never
    blocks the main detection loop.
    """
    global _NR_LAST_FRAME_TS
    now = time.time()
    if (now - _NR_LAST_FRAME_TS) < (1.0 / NR_FRAME_FPS):
        return
    _NR_LAST_FRAME_TS = now

    frame_copy = frame.copy()

    def _send(f):
        try:
            import base64, urllib.request
            ok, buf = cv2.imencode(".jpg", f, [cv2.IMWRITE_JPEG_QUALITY, 65])
            if not ok:
                return
            b64     = base64.b64encode(buf.tobytes()).decode("ascii")
            payload = json.dumps({"image": b64}).encode("utf-8")
            req     = urllib.request.Request(
                NODE_RED_FRAME_URL, data=payload,
                headers={"Content-Type": "application/json"}, method="POST")
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass

    threading.Thread(target=_send, args=(frame_copy,), daemon=True).start()


# ─────────────────────────────────────────────
# UTILITIES
# ─────────────────────────────────────────────

def box_center(box):
    x1, y1, x2, y2 = box
    return ((x1 + x2) / 2, (y1 + y2) / 2)


def box_iou(a, b):
    ax1, ay1, ax2, ay2 = a
    bx1, by1, bx2, by2 = b
    ix    = max(0, min(ax2, bx2) - max(ax1, bx1))
    iy    = max(0, min(ay2, by2) - max(ay1, by1))
    inter = ix * iy
    union = (ax2-ax1)*(ay2-ay1) + (bx2-bx1)*(by2-by1) - inter
    return inter / union if union > 0 else 0


def euclidean(p1, p2):
    return ((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2) ** 0.5


def cosine_sim(a, b):
    return float(np.dot(a, b))


def draw_label(img, text, pos, color):
    scale, thick = 0.42, 1
    (tw, th), _  = cv2.getTextSize(text, _FONT, scale, thick)
    x, y = int(pos[0]), int(pos[1])
    overlay = img.copy()
    cv2.rectangle(overlay, (x, y-th-4), (x+tw+4, y+2), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.55, img, 0.45, 0, img)
    cv2.putText(img, text, (x+2, y-1), _FONT, scale, color, thick, cv2.LINE_AA)


def resolve_class_indices(names_dict):
    trash_idx = cig_idx = None
    for idx, name in names_dict.items():
        nl = name.lower()
        if nl in TRASH_NAMES:     trash_idx = idx
        if nl in CIGARETTE_NAMES: cig_idx   = idx
    if trash_idx is None:
        print("[WARN] Could not find trash class — defaulting to 0")
        trash_idx = 0
    if cig_idx is None:
        print("[WARN] Could not find cigarette class — defaulting to 1")
        cig_idx = 1
    return trash_idx, cig_idx


def estimate_yaw(kp):
    ls = kp[KP_LEFT_SHOULDER]
    rs = kp[KP_RIGHT_SHOULDER]
    if (ls[0] == 0 and ls[1] == 0) or (rs[0] == 0 and rs[1] == 0):
        return "unknown"
    shoulder_w = abs(ls[0] - rs[0])
    if shoulder_w < 20:
        return "left" if ls[0] < rs[0] else "right"
    return "front"


def bottom_center(box):
    x1, y1, x2, y2 = box
    return ((x1 + x2) / 2, y2)


def infer_frame(frame):
    """Return a downscaled copy of frame for model inference (preserves aspect ratio).
    Bounding boxes returned by YOLO will be in the scaled coordinate space —
    callers must scale them back using the ratio returned alongside the frame.
    Returns (infer_img, scale) where scale = infer_size / max(H, W).
    scale = 1.0 means no resize was applied."""
    if INFER_RESIZE is None:
        return frame, 1.0
    h, w = frame.shape[:2]
    long_side = max(h, w)
    if long_side <= INFER_RESIZE:
        return frame, 1.0
    scale = INFER_RESIZE / long_side
    new_w, new_h = int(w * scale), int(h * scale)
    return cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_LINEAR), scale


def point_in_box(pt, box):
    x, y = pt
    x1, y1, x2, y2 = box
    return x1 <= x <= x2 and y1 <= y <= y2


def is_valid_cigarette(cbox, pbox, frame):
    """
    Returns True only if a cigarette box plausibly belongs to this specific
    person — adapted from the sample code's validation logic.
    Checks: size ratio relative to person, aspect ratio, pixel brightness,
    and that the cigarette is in the upper body region.
    """
    px1, py1, px2, py2 = map(int, pbox)
    cx1, cy1, cx2, cy2 = map(int, cbox)
    pw, ph = max(px2 - px1, 1), max(py2 - py1, 1)
    cw, ch = max(cx2 - cx1, 1), max(cy2 - cy1, 1)

    # Cigarette must be plausible size relative to the person
    if not (0.01 * pw <= cw <= 0.30 * pw and 0.01 * ph <= ch <= 0.40 * ph):
        return False

    # Reasonable aspect ratio for a cigarette (elongated)
    ar = ch / cw if cw > 0 else 0
    if not (0.5 <= ar <= 30):
        return False

    # Must not be pure white or pure black (noise / reflection)
    roi = frame[cy1:cy2, cx1:cx2]
    if roi.size > 0:
        mean_v = np.mean(cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY))
        if mean_v > 252 or mean_v < 15:
            return False

    # Cigarette center must fall within the upper 85% of the person box
    # (not at their feet) — with a slight horizontal margin
    upper_box = (
        px1 + int(0.05 * pw), py1,
        px2 - int(0.05 * pw), py1 + int(0.85 * ph),
    )
    if not point_in_box(box_center([cx1, cy1, cx2, cy2]), upper_box):
        return False

    return True


def smoke_plume_check(frame, face_region):
    if not SMOKE_PLUME_ENABLED:
        return False
    fh, fw = frame.shape[:2]
    x1, y1, x2, y2 = face_region
    px1 = int(max(0, x1))
    px2 = int(min(fw, x2))
    py1 = int(max(0, y1 - (y2-y1)*0.5))
    py2 = int(max(0, y1))
    if py2 <= py1 or px2 <= px1:
        return False
    roi = frame[py1:py2, px1:px2]
    if roi.size == 0:
        return False
    hsv  = cv2.cvtColor(roi, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, (0, 0, 120), (180, 60, 255))
    return int(np.count_nonzero(mask)) >= SMOKE_PLUME_MIN_PIXELS


# ─────────────────────────────────────────────
# FACE DATABASE
# ─────────────────────────────────────────────

class FaceDatabase:
    def __init__(self, emb_path=FACE_DB_PATH, meta_path=FACE_META_PATH):
        self.emb_path   = Path(emb_path)
        self.meta_path  = Path(meta_path)
        self.embeddings = np.zeros((0, 512), dtype=np.float32)
        self.meta       = []
        self._load()

    def _load(self):
        if self.emb_path.exists() and self.meta_path.exists():
            self.embeddings = np.load(str(self.emb_path))
            with open(self.meta_path) as f:
                self.meta = json.load(f)
            print(f"[INFO] Face DB loaded: {len(self.meta)} identities")
        else:
            print("[INFO] Face DB empty — starting fresh")

    def save(self):
        np.save(str(self.emb_path), self.embeddings)
        with open(self.meta_path, "w") as f:
            json.dump(self.meta, f, indent=2)

    def enroll(self, embedding, name, watchlist=False):
        emb = embedding / (np.linalg.norm(embedding) + 1e-8)
        self.embeddings = np.vstack([self.embeddings, emb[np.newaxis]])
        self.meta.append({
            "name":        name,
            "watchlist":   watchlist,
            "enrolled_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        })
        self.save()
        print(f"[INFO] Enrolled: {name}  (watchlist={watchlist})")
        return len(self.meta) - 1

    def match(self, embedding):
        if len(self.meta) == 0:
            return "unknown", False, 0.0
        emb      = embedding / (np.linalg.norm(embedding) + 1e-8)
        sims     = self.embeddings @ emb
        best_idx = int(np.argmax(sims))
        best_sim = float(sims[best_idx])
        if best_sim >= FACE_SIM_THRESHOLD:
            m = self.meta[best_idx]
            return m["name"], m.get("watchlist", False), best_sim
        return "unknown", False, best_sim

    def set_watchlist(self, name, status=True):
        changed = 0
        for m in self.meta:
            if m["name"].lower() == name.lower():
                m["watchlist"] = status
                changed += 1
        if changed:
            self.save()
            print(f"[INFO] {name}: watchlist={status} ({changed} entry/entries)")
        else:
            print(f"[WARN] Name '{name}' not found in DB")

    def list_all(self):
        if not self.meta:
            print("  (empty)")
            return
        for i, m in enumerate(self.meta):
            wl = " [WATCHLIST]" if m.get("watchlist") else ""
            print(f"  [{i}] {m['name']}{wl}  enrolled {m['enrolled_at']}")


# ─────────────────────────────────────────────
# FACE RECOGNIZER
# ─────────────────────────────────────────────

class FaceRecognizer:
    def __init__(self, face_db: FaceDatabase):
        self.db     = face_db
        self.app    = None
        self._cache = {}
        if not INSIGHTFACE_OK:
            return
        try:
            self.app = FaceAnalysis(
                name="buffalo_l",
                providers=["CPUExecutionProvider"],
            )
            self.app.prepare(ctx_id=-1, det_size=(320, 320))
            print("[INFO] InsightFace (ArcFace) ready")
        except Exception as e:
            print(f"[WARN] InsightFace init failed: {e}")
            self.app = None

    def process(self, frame, frame_no, offender_boxes=None):
        if self.app is None:
            return []
        if FACE_ON_OFFENDER_ONLY and not offender_boxes:
            return []
        if not FACE_ON_OFFENDER_ONLY:
            if frame_no % FACE_RECOGNITION_EVERY != 0:
                return self._cache.get(
                    frame_no - (frame_no % FACE_RECOGNITION_EVERY), [])

        fh, fw  = frame.shape[:2]
        results = []

        if FACE_ON_OFFENDER_ONLY and offender_boxes:
            seen_faces = set()
            for ob in offender_boxes:
                ox1, oy1, ox2, oy2 = [int(v) for v in ob]
                pad_x = int((ox2-ox1)*0.5)
                pad_y = int((oy2-oy1)*0.3)
                cx1 = max(0, ox1-pad_x); cy1 = max(0, oy1-pad_y)
                cx2 = min(fw, ox2+pad_x); cy2 = min(fh, oy2+pad_y)
                crop = frame[cy1:cy2, cx1:cx2]
                if crop.size == 0:
                    continue
                faces = self.app.get(crop)
                for face in faces:
                    if face.det_score < FACE_DET_SCORE_MIN:
                        continue
                    fb   = face.bbox.astype(int)
                    bbox = [fb[0]+cx1, fb[1]+cy1, fb[2]+cx1, fb[3]+cy1]
                    fcx  = round((bbox[0]+bbox[2])/2/30)*30
                    fcy  = round((bbox[1]+bbox[3])/2/30)*30
                    if (fcx, fcy) in seen_faces:
                        continue
                    seen_faces.add((fcx, fcy))
                    emb  = face.embedding
                    name, watchlist, sim = self.db.match(emb)
                    if name == "unknown" and ENROLL_UNKNOWN:
                        uid  = f"person_{len(self.db.meta):03d}"
                        self.db.enroll(emb, uid, watchlist=False)
                        name = uid
                    results.append({
                        "bbox": bbox, "name": name, "watchlist": watchlist,
                        "similarity": sim, "det_score": float(face.det_score),
                        "embedding": emb,
                    })
        else:
            faces = self.app.get(frame)
            for face in faces:
                if face.det_score < FACE_DET_SCORE_MIN:
                    continue
                bbox = face.bbox.astype(int).tolist()
                emb  = face.embedding
                name, watchlist, sim = self.db.match(emb)
                if name == "unknown" and ENROLL_UNKNOWN:
                    uid  = f"person_{len(self.db.meta):03d}"
                    self.db.enroll(emb, uid, watchlist=False)
                    name = uid
                results.append({
                    "bbox": bbox, "name": name, "watchlist": watchlist,
                    "similarity": sim, "det_score": float(face.det_score),
                    "embedding": emb,
                })

        self._cache[frame_no] = results
        for k in list(self._cache):
            if k < frame_no - 10:
                del self._cache[k]
        return results

    def enroll_from_image(self, img_path, name, watchlist=False):
        if self.app is None:
            print("[ERROR] InsightFace not available")
            return False
        img = cv2.imread(img_path)
        if img is None:
            print(f"[ERROR] Cannot read: {img_path}")
            return False
        faces = self.app.get(img)
        if not faces:
            print("[ERROR] No face detected in image")
            return False
        face = max(faces, key=lambda f: f.det_score)
        self.db.enroll(face.embedding, name, watchlist=watchlist)
        return True


# ─────────────────────────────────────────────
# LOITERING DETECTOR
# ─────────────────────────────────────────────

class LoiteringDetector:
    def __init__(self):
        self._first_seen = {}

    def _in_any_zone(self, cx, cy, fw, fh):
        if not LOITER_ZONES:
            return True
        for x1, y1, x2, y2 in LOITER_ZONES:
            if x1 <= cx <= x2 and y1 <= cy <= y2:
                return True
        return False

    def check(self, person_boxes, fh, fw):
        events = []
        now    = time.time()
        active = set()
        for pbox in person_boxes:
            cx, cy = box_center(pbox)
            if not self._in_any_zone(cx, cy, fw, fh):
                continue
            pkey = (round(cx/50)*50, round(cy/50)*50)
            active.add(pkey)
            if pkey not in self._first_seen:
                self._first_seen[pkey] = now
            dwell = now - self._first_seen[pkey]
            if dwell >= LOITER_SECONDS:
                events.append((pbox, dwell))
        for k in list(self._first_seen):
            if k not in active:
                del self._first_seen[k]
        return events


# ─────────────────────────────────────────────
# TEMPORAL SMOOTHER
# ─────────────────────────────────────────────

class TemporalSmoother:
    def __init__(self, confirm=TEMPORAL_CONFIRM_FRAMES, decay=TEMPORAL_DECAY):
        self.confirm = confirm
        self.decay   = decay
        self._counts = {}

    def update(self, key, detected: bool) -> bool:
        if detected:
            self._counts[key] = min(
                self._counts.get(key, 0.0) + 1.0, self.confirm + 2)
        else:
            self._counts[key] = max(
                0.0, self._counts.get(key, 0.0) - self.decay)
        return self._counts.get(key, 0.0) >= self.confirm

    def reset(self, key):
        self._counts.pop(key, None)


# ─────────────────────────────────────────────
# SMOKING DETECTOR
# ─────────────────────────────────────────────

class SmokingDetector:
    def __init__(self, pose_model_path):
        print(f"[INFO] Loading pose model: {pose_model_path}")
        self.model      = YOLO(pose_model_path)
        self.model.to(YOLO_DEVICE)
        self._confirm   = {}
        self._last_seen = {}
        self._smoother  = TemporalSmoother()

    def _person_key(self, pbox):
        cx, cy = box_center(pbox)
        return (round(cx/50)*50, round(cy/50)*50)

    def check(self, frame, person_boxes, cigarette_boxes,
              cached_pose_res=None, face_results=None):
        detections = []
        fh, fw     = frame.shape[:2]

        if not cigarette_boxes:
            for k in list(self._confirm):
                self._confirm[k] = max(0.0, self._confirm[k] - SMOKING_DECAY)
                self._smoother.update(("smoke", k), False)
            return []

        if not person_boxes:
            # Do NOT fall back to the full frame as a synthetic person box —
            # doing so causes the face recognizer to scan every face in the
            # frame and flag all of them as offenders.  If pose detection
            # found nobody, skip this frame silently.
            return []

        res = cached_pose_res
        if res is None:
            res = self.model.predict(frame, conf=0.3, verbose=False)[0]

        kpts_all = kpts_conf = pose_boxes = None
        if res.keypoints is not None and res.keypoints.xy is not None:
            kpts_all   = res.keypoints.xy.cpu().numpy()
            pose_boxes = res.boxes.xyxy.cpu().numpy()
            if res.keypoints.conf is not None:
                kpts_conf = res.keypoints.conf.cpu().numpy()

        # ── Pre-compute per-person nose positions so we can assign each
        #    cigarette to the SINGLE closest person rather than flagging
        #    every person within the distance threshold.
        _person_meta = []   # [(pbox, nose_pt, face_region, hand_near, best_idx)]
        for pbox in person_boxes:
            x1, y1, x2, y2 = pbox
            person_h = max(y2 - y1, 1)
            person_w = max(x2 - x1, 1)
            nose_pt   = None
            hand_near = False
            body_yaw  = "front"
            best_idx, best_iou = None, max(PERSON_MATCH_IOU_MIN - 0.1, 0.05)
            if kpts_all is not None:
                for i, pb in enumerate(pose_boxes):
                    iou = box_iou(pbox, pb.tolist())
                    if iou > best_iou:
                        best_iou = iou
                        best_idx = i
            if best_idx is not None:
                kp   = kpts_all[best_idx]
                nose = kp[KP_NOSE]
                if not (nose[0] == 0 and nose[1] == 0):
                    nose_pt  = (nose[0], nose[1])
                body_yaw = estimate_yaw(kp)
                if nose_pt is not None:
                    dist_thresh = HAND_MOUTH_DIST_THRESH * person_h
                    for widx in [KP_LEFT_WRIST, KP_RIGHT_WRIST]:
                        wrist = kp[widx]
                        if wrist[0] == 0 and wrist[1] == 0:
                            continue
                        if (kpts_conf is not None and
                                kpts_conf[best_idx][widx] < WRIST_CONF_MIN):
                            continue
                        if euclidean(wrist, nose_pt) < dist_thresh:
                            hand_near = True
                            break
            if nose_pt is None:
                nose_pt = ((x1+x2)/2, y1 + person_h * 0.15)
            h_expand    = 0.80 if body_yaw in ("left", "right") else 0.55
            face_r      = person_h * FACE_REGION_FRAC
            face_region = (
                nose_pt[0] - person_w * h_expand,
                nose_pt[1] - face_r * 0.6,
                nose_pt[0] + person_w * h_expand,
                nose_pt[1] + face_r * 1.2,
            )
            _person_meta.append((pbox, nose_pt, face_region, hand_near, best_idx, person_h, person_w))

        # For each cigarette box find the single closest person (by nose distance
        # then IOU), so only that one person can be confirmed as a smoker.
        _cig_owner: dict[int, int] = {}   # cigarette_idx -> person_meta_idx
        for ci, cb in enumerate(cigarette_boxes):
            cb_center = box_center(cb)
            best_pm_idx  = None
            best_pm_dist = float("inf")
            for pi, (pbox, nose_pt, face_region, hand_near, best_idx, person_h, person_w) in enumerate(_person_meta):
                # Hard gate: cigarette must be plausible in size/position for
                # this specific person before any proximity math is run.
                # Borrowed from sample code — prevents a single cig detection
                # from implicating every person in the frame.
                if not is_valid_cigarette(cb, pbox, frame):
                    continue
                iou  = box_iou(face_region, cb)
                dist = euclidean(nose_pt, cb_center)
                if iou >= CIG_FACE_IOU_MIN or dist < CIG_FACE_DIST_MAX:
                    if dist < best_pm_dist:
                        best_pm_dist = dist
                        best_pm_idx  = pi
            if best_pm_idx is not None:
                # If two cigarettes compete for the same person, keep closer one
                if best_pm_idx not in _cig_owner.values():
                    _cig_owner[ci] = best_pm_idx
                else:
                    # already assigned — only override if this cig is closer
                    prev_ci = next(k for k, v in _cig_owner.items() if v == best_pm_idx)
                    prev_dist = euclidean(
                        _person_meta[best_pm_idx][1], box_center(cigarette_boxes[prev_ci]))
                    if best_pm_dist < prev_dist:
                        del _cig_owner[prev_ci]
                        _cig_owner[ci] = best_pm_idx

        # Build set of person indices that actually own a cigarette
        _smoking_person_indices = set(_cig_owner.values())

        for pi, (pbox, nose_pt, face_region, hand_near, best_idx, person_h, person_w) in enumerate(_person_meta):
            pkey     = self._person_key(pbox)
            x1, y1, x2, y2 = pbox
            self._last_seen[pkey] = time.time()

            cig_near_face  = pi in _smoking_person_indices
            plume_detected = smoke_plume_check(frame, face_region) if cig_near_face else False

            if cig_near_face or plume_detected:
                bonus = (1.0 if hand_near else 0.0) + (0.5 if plume_detected else 0.0)
                self._confirm[pkey] = min(
                    self._confirm.get(pkey, 0.0) + 1.0 + bonus,
                    SMOKING_CONFIRM_FRAMES + 2)
            else:
                self._confirm[pkey] = max(
                    0.0, self._confirm.get(pkey, 0.0) - SMOKING_DECAY)

            primary = self._confirm.get(pkey, 0.0) >= SMOKING_CONFIRM_FRAMES

            if self._smoother.update(("smoke", pkey), primary):
                if hand_near and plume_detected:
                    confidence = "HIGH"
                else:
                    confidence = "MEDIUM"

                face_name = None
                if face_results:
                    for fr in face_results:
                        if box_iou(fr["bbox"], pbox) > 0.05:
                            face_name = fr["name"]
                            break

                detections.append((pbox, confidence, pkey, face_name))

        now = time.time()
        for k in list(self._last_seen):
            if now - self._last_seen[k] > 3.0:
                self._confirm.pop(k, None)
                self._smoother.reset(("smoke", k))
                del self._last_seen[k]

        return detections


# ─────────────────────────────────────────────
# LITTERING DETECTOR
# ─────────────────────────────────────────────

class LitteringDetector:
    def __init__(self):
        self.tracks      = {}
        self.next_id     = 0
        self.debounce    = {}
        self._last_wrist = {}
        self._smoother   = TemporalSmoother(confirm=3, decay=1)

    def _match(self, cx, cy, frame_no, max_dist=100):
        best_id, best_dist = None, max_dist
        for tid, hist in self.tracks.items():
            if not hist:
                continue
            lx, ly, lf = hist[-1]
            if frame_no - lf > 8:
                continue
            d = euclidean((cx, cy), (lx, ly))
            if d < best_dist:
                best_dist, best_id = d, tid
        if best_id is None:
            best_id = self.next_id
            self.next_id += 1
            self.tracks[best_id] = collections.deque(maxlen=TRAJECTORY_HISTORY)
        self.tracks[best_id].append((cx, cy, frame_no))
        return best_id

    def _velocity(self, tid):
        hist = list(self.tracks[tid])
        if len(hist) < 3:
            return 0, 0
        recent = hist[-5:] if len(hist) >= 5 else hist
        n  = len(recent) - 1
        vx = (recent[-1][0] - recent[0][0]) / n
        vy = (recent[-1][1] - recent[0][1]) / n
        return vx, vy

    def _object_left_hand(self, cx, cy, wrist_positions):
        for wx, wy in wrist_positions:
            if euclidean((cx, cy), (wx, wy)) < OBJECT_LEAVE_HAND_PX:
                return False
        return True

    def check(self, trash_boxes, person_boxes, frame_no,
              pose_kpts=None, pose_boxes=None, pose_kpts_conf=None):
        events         = []
        current_wrists = []
        if pose_kpts is not None:
            for kp in pose_kpts:
                for widx in [KP_LEFT_WRIST, KP_RIGHT_WRIST]:
                    wpt = kp[widx]
                    if wpt[0] != 0 or wpt[1] != 0:
                        current_wrists.append((wpt[0], wpt[1]))

        for tbox in trash_boxes:
            cx, cy    = box_center(tbox)
            tid       = self._match(cx, cy, frame_no)
            vx, vy    = self._velocity(tid)
            speed     = (vx**2 + vy**2) ** 0.5
            track_len = len(self.tracks[tid])
            if track_len < TRASH_MIN_TRACK_LEN:
                continue

            # Find the SINGLE nearest person to this trash item (not all
            # persons in range) — prevents flagging every bystander near
            # a piece of trash that only one person could have dropped.
            nearest_pbox  = None
            nearest_pdist = float("inf")
            for pbox in person_boxes:
                px1, py1, px2, py2 = pbox
                if not (px1 - LITTER_PROXIMITY_PX < cx < px2 + LITTER_PROXIMITY_PX and
                        py1 < cy < py2 + LITTER_PROXIMITY_PX):
                    continue
                d = euclidean((cx, cy), bottom_center(pbox))
                if d < nearest_pdist:
                    nearest_pdist = d
                    nearest_pbox  = pbox

            if nearest_pbox is None:
                continue

            # Sample-code idea: if the object center is inside a person's
            # estimated hand zone they're holding it — not littering yet.
            px1n, py1n, px2n, py2n = nearest_pbox
            pw_n = max(px2n - px1n, 1)
            ph_n = max(py2n - py1n, 1)
            hand_w = pw_n * 0.22
            hand_h = ph_n * 0.22
            hand_L = (px1n + 0.12*pw_n, py1n + 0.58*ph_n,
                      px1n + 0.12*pw_n + hand_w, py1n + 0.58*ph_n + hand_h)
            hand_R = (px1n + 0.65*pw_n, py1n + 0.58*ph_n,
                      px1n + 0.65*pw_n + hand_w, py1n + 0.58*ph_n + hand_h)
            if point_in_box((cx, cy), hand_L) or point_in_box((cx, cy), hand_R):
                continue   # person is holding the object — not littering

            left_hand  = self._object_left_hand(cx, cy, current_wrists)
            event_type = confidence = None

            if vy > THROW_VELOCITY_THRESH and speed > THROW_VELOCITY_THRESH:
                event_type = "THROW"
                confidence = "HIGH" if vy > THROW_VELOCITY_THRESH * 1.5 else "MEDIUM"
            elif 6 < vy <= THROW_VELOCITY_THRESH and abs(vx) < 6 and left_hand:
                event_type = "DROP"
                confidence = "MEDIUM"

            if event_type:
                tkey = (tid, event_type)
                if self._smoother.update(tkey, True):
                    if frame_no - self.debounce.get(tkey, -999) > 12:
                        events.append((tbox, event_type, confidence, f"litter_{tid}"))
                        self.debounce[tkey] = frame_no
            else:
                self._smoother.update((tid, "THROW"), False)
                self._smoother.update((tid, "DROP"),  False)

        if pose_kpts is not None and len(pose_kpts) > 0:
            for i, kp in enumerate(pose_kpts):
                if pose_boxes is None or i >= len(pose_boxes):
                    continue
                px1, py1, px2, py2 = pose_boxes[i].tolist()
                person_w = max(px2 - px1, 1)
                person_h = max(py2 - py1, 1)

                for wrist_idx, shoulder_idx in [
                    (KP_LEFT_WRIST,  KP_LEFT_SHOULDER),
                    (KP_RIGHT_WRIST, KP_RIGHT_SHOULDER),
                ]:
                    wpt = kp[wrist_idx]
                    spt = kp[shoulder_idx]
                    if wpt[0] == 0 and wpt[1] == 0:
                        continue
                    if spt[0] == 0 and spt[1] == 0:
                        continue
                    if pose_kpts_conf is not None:
                        if pose_kpts_conf[i][wrist_idx]   < 0.3: continue
                        if pose_kpts_conf[i][shoulder_idx] < 0.3: continue

                    wrist_outside = (
                        wpt[0] < px1 - ARM_EXTEND_THRESH * person_w or
                        wpt[0] > px2 + ARM_EXTEND_THRESH * person_w
                    )
                    wrist_raised = wpt[1] < (py1 + person_h * ARM_RISE_THRESH)
                    if not (wrist_outside and wrist_raised):
                        continue

                    wkey = (i, wrist_idx)
                    last = self._last_wrist.get(wkey)
                    moved = False
                    if last is not None:
                        dx = wpt[0] - last[0]
                        dy = wpt[1] - last[1]
                        moved = (abs(dx) > ARM_WRIST_MOVE_MIN and dy > -5)
                    self._last_wrist[wkey] = (wpt[0], wpt[1])
                    if not moved:
                        continue

                    arm_tid = f"arm_{i}_{wrist_idx}"
                    if self._smoother.update(arm_tid, True):
                        if frame_no - self.debounce.get(arm_tid, -999) > 30:
                            sz        = 40
                            synth_box = (wpt[0]-sz, wpt[1]-sz, wpt[0]+sz, wpt[1]+sz)
                            events.append((synth_box, "ARM-THROW", "HIGH", arm_tid))
                            self.debounce[arm_tid] = frame_no

        stale = [tid for tid, h in self.tracks.items()
                 if not h or frame_no - h[-1][2] > 50]
        for tid in stale:
            self.tracks.pop(tid, None)
            for k in list(self.debounce):
                if isinstance(k, tuple) and k[0] == tid:
                    self.debounce.pop(k, None)

        return events


# ─────────────────────────────────────────────
# STATIONARY TRASH REGISTRY
# ─────────────────────────────────────────────

class StationaryTrashRegistry:
    def __init__(self):
        self._candidates = {}
        self._last_seen  = {}
        self._locked_ids = set()

    def _grid_key(self, cx, cy, grid=30):
        return (round(cx/grid)*grid, round(cy/grid)*grid)

    def _match_or_create(self, cx, cy, frame_no, max_dist=50):
        best_tid, best_dist = None, max_dist
        for tid, info in self._candidates.items():
            d = euclidean((cx, cy), (info["cx"], info["cy"]))
            if d < best_dist:
                best_dist, best_tid = d, tid
        if best_tid is None:
            best_tid = self._grid_key(cx, cy)
            self._candidates[best_tid] = {
                "cx": cx, "cy": cy,
                "since_frame": frame_no,
                "locked": False,
            }
        return best_tid

    def update(self, trash_boxes, frame_no):
        active_tids      = set()
        stationary_boxes = []
        new_boxes        = []

        for box in trash_boxes:
            cx, cy = box_center(box)
            tid    = self._match_or_create(cx, cy, frame_no)
            active_tids.add(tid)

            info = self._candidates[tid]
            self._last_seen[tid] = frame_no

            moved = (euclidean((cx, cy), (info["cx"], info["cy"]))
                     > STATIONARY_MOVE_THRESH)
            if moved:
                info["cx"]          = cx
                info["cy"]          = cy
                info["since_frame"] = frame_no
                info["locked"]      = False
                self._locked_ids.discard(tid)
            else:
                info["cx"] = info["cx"] * 0.8 + cx * 0.2
                info["cy"] = info["cy"] * 0.8 + cy * 0.2

            frames_still = frame_no - info["since_frame"]
            if frames_still >= STATIONARY_LOCK_FRAMES and not info["locked"]:
                info["locked"] = True
                self._locked_ids.add(tid)
                print(f"[LOCK] Trash {tid} locked as stationary")

            if info["locked"]:
                stationary_boxes.append(box)
            else:
                new_boxes.append(box)

        for tid in list(self._last_seen):
            if frame_no - self._last_seen[tid] > STATIONARY_PURGE_FRAMES:
                self._candidates.pop(tid, None)
                self._last_seen.pop(tid, None)
                self._locked_ids.discard(tid)

        return stationary_boxes, new_boxes


# ─────────────────────────────────────────────
# ALERT MANAGER
# ─────────────────────────────────────────────

class AlertManager:
    def __init__(self, save_dir="alerts", db=None):
        self.save_dir        = Path(save_dir)
        self.save_dir.mkdir(exist_ok=True)
        self.saved_offenders = set()
        self.per_offender_cd = {}
        self._frame_buffer   = collections.deque(maxlen=999)
        self.db              = db

    def push_frame(self, frame, fps):
        if SAVE_VIDEO_CLIP:
            keep = int(CLIP_BUFFER_SECONDS * fps)
            self._frame_buffer = collections.deque(
                list(self._frame_buffer)[-keep:] + [frame.copy()], maxlen=keep)

    def trigger(self, frame, label, confidence, offender_key=None,
                metadata=None, fps=30, frame_no=0, bounding_box=None):
        if confidence not in SAVEABLE_CONFIDENCES:
            return

        save_key = offender_key or label
        if save_key in self.saved_offenders:
            return

        now = time.time()
        if now - self.per_offender_cd.get(save_key, 0) < ALERT_COOLDOWN_SEC:
            return

        self.saved_offenders.add(save_key)
        self.per_offender_cd[save_key] = now

        ts   = time.strftime("%Y%m%d_%H%M%S")
        stem = f"{label}_{confidence}_{save_key}_{ts}"

        jpg_path = self.save_dir / f"{stem}.jpg"
        cv2.imwrite(str(jpg_path), frame)

        from datetime import datetime
        meta = {
            "label":        label,
            "confidence":   confidence,
            "offender_key": str(save_key),
            "timestamp":    datetime.utcnow(),
            "frame_no":     frame_no,
            "bounding_box": bounding_box or [],
        }
        if metadata:
            meta.update(metadata)

        json_path = self.save_dir / f"{stem}.json"
        with open(json_path, "w") as f:
            json.dump(meta, f, indent=2, default=str)

        clip_path = None
        if SAVE_VIDEO_CLIP and self._frame_buffer:
            h, w      = frame.shape[:2]
            clip_path = str(self.save_dir / f"{stem}.mp4")
            writer    = cv2.VideoWriter(
                clip_path, cv2.VideoWriter_fourcc(*"mp4v"), fps, (w, h))
            for frm in self._frame_buffer:
                writer.write(frm)
            writer.release()

        if WEBHOOK_URL:
            self._post_webhook(meta, str(jpg_path))

        if self.db:
            try:
                self.db.log_violation(
                    type=label, confidence=confidence,
                    offender_key=str(save_key), frame_no=frame_no,
                    bounding_box=bounding_box or [], image_path=str(jpg_path),
                    extra={
                        "json_path":  str(json_path),
                        "clip_path":  clip_path,
                        "face_name":  meta.get("face_name"),
                        "person_key": meta.get("person_key"),
                        "similarity": meta.get("similarity"),
                    }
                )
                print("[DB] Inserted")
            except Exception as e:
                print("[DB ERROR]", e)

        print(f"[ALERT] {label} ({confidence}) -> {stem}")

        notify_node_red(
            label, confidence,
            bounding_box or [], str(jpg_path),
            save_key, metadata=meta,
        )

    def _post_webhook(self, meta, img_path):
        try:
            import urllib.request
            data = json.dumps(meta).encode()
            req  = urllib.request.Request(
                WEBHOOK_URL, data=data,
                headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=2)
        except Exception as e:
            print("[WEBHOOK ERROR]", e)

    def draw_banner(self, frame, alerts):
        if not alerts:
            return frame
        fh, fw = frame.shape[:2]
        # Deduplicate and abbreviate alert labels for a clean ticker
        seen  = set()
        short = []
        abbrev = {"SMOKING": "SMK", "LITTERING": "LTR",
                  "LOITERING": "LOI", "WATCHLIST": "WL!"}
        for a in alerts:
            key = a.split()[0]
            if key not in seen:
                seen.add(key)
                tag = abbrev.get(key.upper(), key[:3].upper())
                short.append(tag)
        ticker = "  ⚠  " + "  |  ".join(short)
        scale, thick = 0.40, 1
        (tw, th), _  = cv2.getTextSize(ticker, _FONT, scale, thick)
        pad  = 6
        bx1  = fw - tw - pad*2 - 2
        by1  = fh - th - pad*2 - 4
        bx2  = fw - 2
        by2  = fh - 2
        overlay = frame.copy()
        cv2.rectangle(overlay, (bx1, by1), (bx2, by2), (20, 20, 20), -1)
        cv2.addWeighted(overlay, 0.65, frame, 0.35, 0, frame)
        cv2.putText(frame, ticker, (bx1+pad, by2-pad),
                    _FONT, scale, (0, 80, 255), thick, cv2.LINE_AA)
        return frame


# ─────────────────────────────────────────────
# DRAW FACE OVERLAYS
# ─────────────────────────────────────────────

def draw_faces(display, face_results):
    for fr in face_results:
        x1, y1, x2, y2 = fr["bbox"]
        name      = fr["name"]
        watchlist = fr["watchlist"]
        sim       = fr["similarity"]
        if watchlist:
            col = COL_FACE_WL
            lbl = f"! {name}"
        elif name == "unknown":
            col = COL_FACE_UNK
            lbl = "?"
        else:
            col = COL_FACE_OK
            lbl = name
        cv2.rectangle(display, (x1, y1), (x2, y2), col, 1)
        draw_label(display, lbl, (x1, y1-3), col)


# ─────────────────────────────────────────────
# MAIN PIPELINE
# ─────────────────────────────────────────────

def run(source, conf_thresh, show, save_video, debug_mode,
        smoking_det=None, litter_det=None, loiter_det=None,
        alert_mgr=None, face_recognizer=None,
        model_a_holder=None, model_a_trash=0, model_a_cig=1,
        model_b=None, model_b_trash=0, model_b_cig=1,
        model_coco=None,
        trash_registry=None,
        db: SurveillanceDB = None):

    if smoking_det    is None: smoking_det    = SmokingDetector(POSE_MODEL_PATH)
    if litter_det     is None: litter_det     = LitteringDetector()
    if loiter_det     is None: loiter_det     = LoiteringDetector()
    if alert_mgr      is None: alert_mgr      = AlertManager(db=db)
    if trash_registry is None: trash_registry = StationaryTrashRegistry()
    if face_recognizer is None and INSIGHTFACE_OK:
        face_recognizer = FaceRecognizer(FaceDatabase())

    model_a = model_a_holder["model"] if model_a_holder else None

    is_image = isinstance(source, str) and \
               source.lower().endswith((".jpg", ".jpeg", ".png", ".bmp", ".webp"))

    if is_image:
        frame_list = [cv2.imread(source)]
        if frame_list[0] is None:
            raise RuntimeError(f"Cannot read: {source}")
        fps, cap = 1, None
    else:
        src = int(source) if str(source).isdigit() else source
        cap = cv2.VideoCapture(src)
        if not cap.isOpened():
            raise RuntimeError(f"Cannot open: {source}")
        fps = cap.get(cv2.CAP_PROP_FPS) or 30

    writer = None
    if save_video and not is_image:
        W, H   = int(cap.get(3)), int(cap.get(4))
        writer = cv2.VideoWriter(
            "surveillance_output.mp4",
            cv2.VideoWriter_fourcc(*"mp4v"), fps, (W, H))
        print("[INFO] Recording to surveillance_output.mp4")

    frame_no  = 0
    db_status = db.status() if db else {"mode": "none"}

    print(f"[INFO] Running — DB: {db_status['mode'].upper()} — press Q to quit")
    print(f"[INFO] Thresholds — Trash: {TRASH_CONF_THRESHOLD} | Cig: {CIG_CONF_THRESHOLD}")
    print(f"[INFO] Node-RED frames: {NR_FRAME_FPS} fps → {NODE_RED_FRAME_URL}")
    print(f"[INFO] Keys: Q=quit")

    while True:
        if is_image:
            if frame_no >= len(frame_list):
                break
            frame = frame_list[frame_no]
        else:
            ret, frame = cap.read()
            if not ret:
                break

        frame_no += 1

        if model_a_holder:
            model_a = model_a_holder["model"]

        alert_mgr.push_frame(frame, fps)

        if FRAME_SKIP > 1 and frame_no % FRAME_SKIP != 0 and not is_image:
            if show:
                cv2.imshow("Smart Surveillance", frame)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            continue

        display       = frame.copy()
        active_alerts = []
        fh, fw        = frame.shape[:2]

        # ── Helpers ───────────────────────────────────────────────
        infer_img, infer_scale = infer_frame(frame)

        def scale_box(bx):
            """Scale a box from inference coords back to display coords."""
            if infer_scale == 1.0:
                return bx
            return [v / infer_scale for v in bx]

        def collect_boxes(model, trash_idx, cig_idx, label):
            if model is None:
                return [], []
            res    = model.predict(infer_img, conf=TRASH_CONF_THRESHOLD,
                                   device=YOLO_DEVICE, verbose=False)[0]
            t_list, c_list = [], []
            for box in res.boxes:
                cls    = int(box.cls[0])
                conf_v = float(box.conf[0])
                bx     = scale_box(box.xyxy[0].tolist())
                if debug_mode:
                    name = model.names.get(cls, str(cls))
                    print(f"[DEBUG] {label} cls={cls}({name}) conf={conf_v:.3f}")
                if cls == cig_idx and conf_v >= CIG_CONF_THRESHOLD:
                    c_list.append(bx + [conf_v])
                elif cls == trash_idx and conf_v >= TRASH_CONF_THRESHOLD:
                    t_list.append(bx + [conf_v])
            return t_list, c_list

        def merge_detections(list_a, list_b, iou_thresh=0.45):
            merged = list(list_a)
            for b in list_b:
                overlaps = False
                for idx, m in enumerate(merged):
                    if box_iou(b[:4], m[:4]) >= iou_thresh:
                        overlaps = True
                        if b[4] > m[4]:
                            merged[idx] = b
                        break
                if not overlaps:
                    merged.append(b)
            return merged

        # ── 1. Custom models ──────────────────────────────────────
        a_trash, a_cig = collect_boxes(model_a, model_a_trash, model_a_cig, "A")
        b_trash, b_cig = collect_boxes(model_b, model_b_trash, model_b_cig, "B")
        merged_trash   = merge_detections(a_trash, b_trash)
        merged_cig     = merge_detections(a_cig,   b_cig)

        cigarette_boxes, n_cig = [], 0
        for det in merged_cig:
            bx     = det[:4]
            conf_v = det[4]
            cigarette_boxes.append(bx)
            n_cig += 1
            x1, y1, x2, y2 = [int(v) for v in bx]
            cv2.rectangle(display, (x1, y1), (x2, y2), COL_SMOKING, 1)
            draw_label(display, f"cig {conf_v:.2f}", (x1, y1), COL_SMOKING)

        raw_trash_boxes = [det[:4] for det in merged_trash]

        # ── 2. COCO fallback ──────────────────────────────────────
        if model_coco and frame_no % COCO_SKIP_FRAMES == 0:
            res_fb = model_coco.predict(
                frame, conf=TRASH_CONF_THRESHOLD, verbose=False)[0]
            for box in res_fb.boxes:
                cls    = int(box.cls[0])
                conf_v = float(box.conf[0])
                bx     = box.xyxy[0].tolist()
                if cls in COCO_TRASH_CLASSES:
                    already = any(box_iou(bx, e) > 0.3 for e in raw_trash_boxes)
                    if not already:
                        raw_trash_boxes.append(bx)

        # ── 3. Stationary registry ────────────────────────────────
        stationary_trash, new_trash = trash_registry.update(raw_trash_boxes, frame_no)

        for box in stationary_trash:
            x1, y1, x2, y2 = [int(v) for v in box]
            cv2.rectangle(display, (x1, y1), (x2, y2), COL_STATIONARY, 1)
            draw_label(display, "existing", (x1, y1), COL_STATIONARY)

        n_trash = len(new_trash)
        for box in new_trash:
            x1, y1, x2, y2 = [int(v) for v in box]
            cv2.rectangle(display, (x1, y1), (x2, y2), COL_TRASH, 2)

        # ── 4. Pose (shared) ──────────────────────────────────────
        pose_res     = None
        person_boxes = []
        run_pose     = bool(cigarette_boxes or new_trash or smoking_det._confirm)

        if run_pose:
            pose_res = smoking_det.model.predict(frame, conf=0.25, verbose=False)[0]
            for box in pose_res.boxes:
                if int(box.cls[0]) == 0:
                    bx = box.xyxy[0].tolist()
                    person_boxes.append(bx)
                    x1, y1, x2, y2 = [int(v) for v in bx]
                    cv2.rectangle(display, (x1, y1), (x2, y2), COL_PERSON, 1)

            if (pose_res.keypoints is not None and
                    pose_res.keypoints.xy is not None):
                kpts_all = pose_res.keypoints.xy.cpu().numpy()
                kc = (pose_res.keypoints.conf.cpu().numpy()
                      if pose_res.keypoints.conf is not None else None)
                for i, kp in enumerate(kpts_all):
                    nose = kp[KP_NOSE]
                    if nose[0] == 0 and nose[1] == 0:
                        continue
                    cv2.circle(display, (int(nose[0]), int(nose[1])),
                               5, (0, 255, 255), -1)
                    for widx in [KP_LEFT_WRIST, KP_RIGHT_WRIST]:
                        wpt = kp[widx]
                        if wpt[0] == 0 and wpt[1] == 0:
                            continue
                        if kc is not None and kc[i][widx] < 0.3:
                            continue
                        cv2.circle(display,
                                   (int(wpt[0]), int(wpt[1])), 4, COL_POSE, -1)
                        cv2.line(display,
                                 (int(wpt[0]), int(wpt[1])),
                                 (int(nose[0]), int(nose[1])),
                                 COL_POSE, 1, cv2.LINE_AA)

        # ── 5. Detectors ──────────────────────────────────────────
        smoking_hits = smoking_det.check(
            frame, person_boxes, cigarette_boxes,
            cached_pose_res=pose_res, face_results=[])

        _pkpts = _pboxes = _pkpts_conf = None
        if (pose_res is not None and
                pose_res.keypoints is not None and
                pose_res.keypoints.xy is not None):
            _pkpts  = pose_res.keypoints.xy.cpu().numpy()
            _pboxes = pose_res.boxes.xyxy.cpu().numpy()
            if pose_res.keypoints.conf is not None:
                _pkpts_conf = pose_res.keypoints.conf.cpu().numpy()

        littering_hits = litter_det.check(
            new_trash, person_boxes, frame_no,
            pose_kpts=_pkpts, pose_boxes=_pboxes, pose_kpts_conf=_pkpts_conf)

        loitering_hits = loiter_det.check(person_boxes, fh, fw)

        # ── 6. Face recognition ───────────────────────────────────
        offender_boxes = (
            [pbox for pbox, _, _, _ in smoking_hits] +
            [tbox for tbox, _, _, _ in littering_hits] +
            [pbox for pbox, _       in loitering_hits]
        )

        face_results = []
        if face_recognizer is not None:
            face_results = face_recognizer.process(
                frame, frame_no, offender_boxes=offender_boxes)
            if face_results:
                draw_faces(display, face_results)

            for fr in face_results:
                if fr["watchlist"]:
                    lbl = f"WATCHLIST:{fr['name']}"
                    active_alerts.append(lbl)
                    alert_mgr.trigger(
                        frame, "watchlist", "HIGH",
                        offender_key=f"wl_{fr['name']}",
                        metadata={"face_name":  fr["name"],
                                  "similarity": fr["similarity"]},
                        frame_no=frame_no, bounding_box=fr["bbox"],
                    )

        # ── 7. Smoking alerts ─────────────────────────────────────
        for pbox, conf_s, pkey, _ in smoking_hits:
            face_name = None
            for fr in face_results:
                if box_iou(fr["bbox"], pbox) > 0.05:
                    face_name = fr["name"]
                    break
            x1, y1, x2, y2 = [int(v) for v in pbox]
            cv2.rectangle(display, (x1, y1), (x2, y2), COL_SMOKING, 2)
            who = face_name if face_name and face_name != "unknown" else ""
            lbl = f"SMK {who}".strip()
            draw_label(display, lbl, (x1, y1-4), COL_SMOKING)
            active_alerts.append("SMOKING")
            offender_key = (f"smoke_{face_name}"
                            if face_name and face_name != "unknown"
                            else f"smoke_{pkey}")
            alert_mgr.trigger(
                frame, "smoking", conf_s,
                offender_key=offender_key,
                metadata={"face_name": face_name, "person_key": str(pkey)},
                frame_no=frame_no, bounding_box=list(pbox),
            )

        # ── 8. Littering alerts ───────────────────────────────────
        for tbox, ev, conf_l, track_key in littering_hits:
            x1, y1, x2, y2 = [int(v) for v in tbox]
            cv2.rectangle(display, (x1, y1), (x2, y2), COL_TRASH, 2)
            lbl = f"LTR {ev[:3]}"
            draw_label(display, lbl, (x1, y1-4), COL_TRASH)
            active_alerts.append("LITTERING")
            alert_mgr.trigger(
                frame, f"litter_{ev.lower()}", conf_l,
                offender_key=track_key,
                frame_no=frame_no, bounding_box=list(tbox),
            )

        # ── 9. Loitering alerts ───────────────────────────────────
        for pbox, dwell in loitering_hits:
            x1, y1, x2, y2 = [int(v) for v in pbox]
            cv2.rectangle(display, (x1, y1), (x2, y2), COL_LOITER, 2)
            lbl = f"LOI {int(dwell)}s"
            draw_label(display, lbl, (x1, y1-4), COL_LOITER)
            active_alerts.append("LOITERING")
            pkey = (round((x1+x2)/100)*50, round((y1+y2)/100)*50)
            alert_mgr.trigger(
                frame, "loitering", "MEDIUM",
                offender_key=f"loiter_{pkey}",
                frame_no=frame_no, bounding_box=list(pbox),
            )

        # ── 10. HUD ───────────────────────────────────────────────
        display = alert_mgr.draw_banner(display, active_alerts)
        cv2.putText(display, time.strftime("%Y-%m-%d %H:%M:%S"),
                    (8, display.shape[0]-10), _FONT, 0.5, COL_INFO, 1)
        cv2.putText(display, f"Frame {frame_no}",
                    (display.shape[1]-130, display.shape[0]-10),
                    _FONT, 0.5, COL_INFO, 1)

        if db is not None:
            mode_str = "DB: CLOUD" if db.online else "DB: LOCAL"
            mode_col = COL_INFO if db.online else COL_DEBUG
            cv2.putText(display, mode_str, (8, 20), _FONT, 0.5, mode_col, 1)

        hud_rows = [
            (f"Persons : {len(person_boxes)}",          COL_PERSON),
            (f"Trash   : {n_trash}",                    COL_TRASH),
            (f"Cigs    : {n_cig}",                      COL_SMOKING),
            (f"Faces   : {len(face_results)}",          COL_FACE_OK),
            (f"Saved   : {len(alert_mgr.saved_offenders)}", COL_INFO),
            (f"NR: {NR_FRAME_FPS}fps",                  COL_INFO),
        ]
        for row_idx, (txt, col) in enumerate(hud_rows):
            cv2.putText(display, txt,
                        (display.shape[1]-210, 70 + row_idx*20),
                        _FONT, 0.45, col, 1)

        if writer:
            writer.write(display)

        # ── 11. Stream annotated frame to Node-RED (throttled) ────
        send_frame_to_node_red(display)

        # ── 12. Local display + keyboard ──────────────────────────
        if show or is_image:
            cv2.imshow("Smart Surveillance", display)
            wait = 0 if is_image else max(1, int(1000 / fps))
            key  = cv2.waitKey(wait) & 0xFF
            if key in (ord("q"), 27):
                break

    if cap:    cap.release()
    if writer: writer.release()
    cv2.destroyAllWindows()
    print(f"[INFO] Done. {len(alert_mgr.saved_offenders)} unique offenders captured.")
    print(f"[INFO] Alerts saved to: {alert_mgr.save_dir}/")


# ─────────────────────────────────────────────
# MODEL LOADER
# ─────────────────────────────────────────────

def load_model(model_path, label):
    if not model_path or not os.path.exists(model_path):
        print(f"[WARN] '{model_path}' not found — {label} disabled.")
        return None, 0, 1
    model = YOLO(model_path)
    model.to(YOLO_DEVICE)
    print(f"\n[INFO] Loaded {label}: {model_path}  (device={YOLO_DEVICE})")
    print(f"[INFO]   classes : {model.names}")
    trash_idx, cig_idx = resolve_class_indices(model.names)
    print(f"[INFO]   trash={trash_idx}, cig={cig_idx}")
    return model, trash_idx, cig_idx


def load_coco_fallback():
    try:
        model = YOLO(COCO_FALLBACK_PATH)
        model.to(YOLO_DEVICE)
        print(f"[INFO] COCO fallback loaded: {COCO_FALLBACK_PATH}  (device={YOLO_DEVICE})")
        return model
    except Exception as e:
        print(f"[WARN] COCO fallback failed: {e}")
        return None


# ─────────────────────────────────────────────
# INTERACTIVE MENU
# ─────────────────────────────────────────────

def print_menu():
    print("\n" + "="*52)
    print("   SMART SURVEILLANCE SYSTEM v5")
    print("   Core Edition")
    print("="*52)
    print("  [1]  Image file")
    print("  [2]  Video file")
    print("  [3]  Webcam")
    print("  [4]  IP / RTSP camera")
    print("  [5]  Enroll a face")
    print("  [6]  List enrolled faces")
    print("  [7]  Set watchlist flag")
    print("  [X]  Exit")
    print("="*52)
    print("  Runtime keys: Q=quit")


def ask_source(face_recognizer):
    while True:
        print_menu()
        choice = input("\n  Enter choice [1-7 / X]: ").strip().lower()
        if choice == "x":
            return None, None
        elif choice == "1":
            path = input("  Image path: ").strip().strip("\"'")
            if not os.path.exists(path):
                print(f"  [ERROR] Not found: {path}")
                continue
            return path, False
        elif choice == "2":
            path = input("  Video path: ").strip().strip("\"'")
            if not os.path.exists(path):
                print(f"  [ERROR] Not found: {path}")
                continue
            save = input("  Save output? [y/N]: ").strip().lower() == "y"
            return path, save
        elif choice == "3":
            cams = []
            print("  Scanning...", end="", flush=True)
            for i in range(4):
                cap_t = cv2.VideoCapture(i)
                if cap_t.isOpened():
                    cams.append(i)
                    cap_t.release()
            print(" done.")
            if not cams:
                print("  [ERROR] No webcam.")
                continue
            cam_id = (cams[0] if len(cams) == 1 else
                      int(input(f"  Camera [{cams[0]}]: ").strip() or cams[0]))
            save = input("  Save output? [y/N]: ").strip().lower() == "y"
            return str(cam_id), save
        elif choice == "4":
            url = input("  RTSP URL: ").strip().strip("\"'")
            if not url:
                print("  [ERROR] URL empty.")
                continue
            save = input("  Save output? [y/N]: ").strip().lower() == "y"
            return url, save
        elif choice == "5":
            if face_recognizer is None:
                print("  [ERROR] InsightFace not available")
                continue
            path = input("  Image path: ").strip().strip("\"'")
            if not os.path.exists(path):
                print(f"  [ERROR] Not found: {path}")
                continue
            name = input("  Name for this person: ").strip()
            wl   = input("  Add to watchlist? [y/N]: ").strip().lower() == "y"
            face_recognizer.enroll_from_image(path, name, watchlist=wl)
        elif choice == "6":
            if face_recognizer is None:
                print("  [ERROR] InsightFace not available")
                continue
            face_recognizer.db.list_all()
        elif choice == "7":
            if face_recognizer is None:
                print("  [ERROR] InsightFace not available")
                continue
            name = input("  Person name: ").strip()
            wl   = input("  Set watchlist ON? [Y/n]: ").strip().lower() != "n"
            face_recognizer.db.set_watchlist(name, wl)
        else:
            print("  [ERROR] Enter 1-7 or X.")


# ─────────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────────

if __name__ == "__main__":
    ap = argparse.ArgumentParser(
        description="Smart Surveillance v5 — Core Edition")
    ap.add_argument("--model-a",       default=DEFAULT_MODEL_A)
    ap.add_argument("--model-b",       default=DEFAULT_MODEL_B)
    ap.add_argument("--conf",          type=float, default=CONF_THRESHOLD)
    ap.add_argument("--no-show",       action="store_true")
    ap.add_argument("--no-fallback",   action="store_true")
    ap.add_argument("--debug",         action="store_true")
    ap.add_argument("--source",        default=None)
    ap.add_argument("--save-video",    action="store_true")
    ap.add_argument("--enroll-face",   default=None, metavar="IMAGE")
    ap.add_argument("--name",          default=None)
    ap.add_argument("--watchlist-add", default=None, metavar="NAME")
    ap.add_argument("--watchlist-rm",  default=None, metavar="NAME")
    ap.add_argument("--list-faces",    action="store_true")
    ap.add_argument("--nr-fps",        type=int, default=NR_FRAME_FPS,
                    help="Annotated frames per second sent to Node-RED (default 2)")
    args = ap.parse_args()

    if args.nr_fps != NR_FRAME_FPS:
        NR_FRAME_FPS = args.nr_fps
        print(f"[INFO] Node-RED frame rate set to {NR_FRAME_FPS} fps")

    print("\n[INFO] Connecting to database...")
    _db = SurveillanceDB()
    time.sleep(1)

    print("\n[INFO] Loading models...")
    _model_a, _a_trash, _a_cig = load_model(args.model_a, "model-A")
    _model_b, _b_trash, _b_cig = load_model(args.model_b, "model-B")

    if _model_a is None and _model_b is None:
        print("[ERROR] No valid models. Provide at least one best.pt.")
        import sys; sys.exit(1)

    _model_coco = None if args.no_fallback else load_coco_fallback()

    _model_a_holder = {"model": _model_a}

    _face_db    = FaceDatabase()
    _face_recog = FaceRecognizer(_face_db) if INSIGHTFACE_OK else None

    if args.list_faces:
        _face_db.list_all()
        import sys; sys.exit(0)
    if args.enroll_face:
        if _face_recog is None:
            print("[ERROR] InsightFace not available")
            import sys; sys.exit(1)
        name = args.name or Path(args.enroll_face).stem
        _face_recog.enroll_from_image(args.enroll_face, name)
        import sys; sys.exit(0)
    if args.watchlist_add:
        _face_db.set_watchlist(args.watchlist_add, True)
        import sys; sys.exit(0)
    if args.watchlist_rm:
        _face_db.set_watchlist(args.watchlist_rm, False)
        import sys; sys.exit(0)

    _smoking_det    = SmokingDetector(POSE_MODEL_PATH)
    _litter_det     = LitteringDetector()
    _loiter_det     = LoiteringDetector()
    _trash_registry = StationaryTrashRegistry()
    _alert_mgr      = AlertManager(db=_db)

    print(f"[INFO] Node-RED alert URL : {NODE_RED_URL}")
    print(f"[INFO] Node-RED frame URL : {NODE_RED_FRAME_URL}")
    print(f"[INFO] Node-RED frame rate: {NR_FRAME_FPS} fps")
    print("[INFO] Ready.\n")

    def _run(source, save_video):
        _db.start_session()
        try:
            run(
                source,
                conf_thresh      = args.conf,
                show             = not args.no_show,
                save_video       = save_video,
                debug_mode       = args.debug,
                smoking_det      = _smoking_det,
                litter_det       = _litter_det,
                loiter_det       = _loiter_det,
                alert_mgr        = _alert_mgr,
                face_recognizer  = _face_recog,
                model_a_holder   = _model_a_holder,
                model_a_trash    = _a_trash,
                model_a_cig      = _a_cig,
                model_b          = _model_b,
                model_b_trash    = _b_trash,
                model_b_cig      = _b_cig,
                model_coco       = _model_coco,
                trash_registry   = _trash_registry,
                db               = _db,
            )
        finally:
            _db.end_session()

    if args.source is not None:
        try:
            _run(args.source, args.save_video)
        except Exception as exc:
            print(f"\n  [ERROR] {exc}")
    else:
        while True:
            source, save_video = ask_source(_face_recog)
            if source is None:
                print("\n  Goodbye!\n")
                break
            try:
                _run(source, save_video)
            except Exception as exc:
                print(f"\n  [ERROR] {exc}")
            print("\n  Session ended. Returning to menu...")
